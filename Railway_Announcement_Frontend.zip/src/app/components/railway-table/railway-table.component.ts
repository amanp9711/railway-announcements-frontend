import { Component } from '@angular/core';

@Component({
  selector: 'app-railway-table',
  templateUrl: './railway-table.component.html',
  styleUrls: ['./railway-table.component.scss']
})
export class RailwayTableComponent {

}
