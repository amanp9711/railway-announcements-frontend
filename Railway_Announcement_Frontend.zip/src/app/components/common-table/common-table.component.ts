import { Component, ElementRef, Input, ViewChild, Renderer2, SimpleChanges, OnChanges } from '@angular/core';
import * as moment from 'moment';
import { AnnouncementModel } from '../../models/announcement.model';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-common-table',
  templateUrl: './common-table.component.html',
  styleUrls: ['./common-table.component.scss']
})
export class CommonTableComponent implements OnChanges {

  @Input()
  dataSource: MatTableDataSource<AnnouncementModel> = new MatTableDataSource<AnnouncementModel>([]);

  @Input()
  displayedColumns: string[] = [];

  constructor(private renderer: Renderer2) {

  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['dataSource'] && !changes['dataSource'].firstChange) {
      if (changes['dataSource'].currentValue?.length > changes['dataSource'].previousValue?.length) {
        this.scrollTableToBottom();
      }
    }
  }

  @ViewChild('tableContainer') tableContainer: any;
  @ViewChild('table') table: any;


  formatDate(date: Date): string {
    return moment(date).format('DD/MM/YYYY HH:mm');
  }

  scrollTableToBottom(): void {
    if (this.tableContainer?.nativeElement && this.table?._elementRef) {
      const tableContainer = this.tableContainer.nativeElement;
      const table = this.table._elementRef.nativeElement;
      const scrollHeight = table.scrollHeight;
      this.renderer.setProperty(tableContainer, 'scrollTop', scrollHeight);
    }

  }
}
