import { Component, OnInit } from '@angular/core';
import { AnnouncementModel } from '../../models/announcement.model';
import { MatDialog } from '@angular/material/dialog';
import { RailwayTypes } from '../../models/constants';
import { PopUpFormComponent } from '../pop-up-form/pop-up-form.component';
import { MatTableDataSource } from '@angular/material/table';
import * as moment from 'moment';
import { HttpService } from '../../services/http.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {

  constructor(private dialog: MatDialog, private httpService: HttpService) { }
  ngOnInit(): void {
    this.fetchData();
  }

  fetchData(): void {
    this.httpService.getAnnouncements().subscribe((res: any) => {
      this.dataSource = res;
    })
  }
  dataSource = new MatTableDataSource<AnnouncementModel>([]);

  displayedColumns: string[] = ['name', 'type', 'averageSpeed', 'destinationStation', 'currentStation', 'estimatedTime', 'actions'];

  editData(data: AnnouncementModel): void {

    const announcementModel: AnnouncementModel = structuredClone(data);
    const dialogRef = this.dialog.open(PopUpFormComponent, {
      data: announcementModel
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log(`Dialog result: ${result}`);
      this.fetchData();
    });
  }

  deleteData(data: AnnouncementModel): void {
    if (data.id) {
      this.httpService.deleteAnnouncement(data.id).subscribe()
    }
  }

  createData(): void {
    const announcementModel: AnnouncementModel =
    {
      name: '',
      type: RailwayTypes[0],
      estimatedTime: new Date(),
      averageSpeed: 1,
      currentStation: '',
      destinationStation: ''
    };
    const dialogRef = this.dialog.open(PopUpFormComponent, {
      data: announcementModel
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log(`Dialog result: ${result}`);
      this.fetchData();
    });
  }

  formatDate(date: Date): string {
    return moment(date).format('DD/MM/YYYY HH:mm');
  }
}
