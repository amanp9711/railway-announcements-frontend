import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { RailwayTypes } from '../../models/constants';
import { AnnouncementModel } from '../../models/announcement.model';
import { HttpService } from '../../services/http.service';
import * as moment from 'moment';

@Component({
  selector: 'app-pop-up-form',
  templateUrl: './pop-up-form.component.html',
  styleUrls: ['./pop-up-form.component.scss']
})
export class PopUpFormComponent implements OnInit {

  public types: string[] = RailwayTypes;
  public estimatedTime: string = '12:00 AM'
  public estimatedDate: Date = new Date();

  constructor(private dialogRef: MatDialogRef<PopUpFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AnnouncementModel,
    public httpService: HttpService
  ) { }

  ngOnInit(): void {
    this.estimatedDate = new Date(this.data.estimatedTime);
    this.estimatedTime = moment(this.data.estimatedTime).format('hh:mm A');
  }

  closeDialog(): void {
    this.dialogRef.close();
  }


  onSubmit(): void {
    const dateTimestamp: number = this.estimatedDate.getTime();
    const timeParts: string[] = this.estimatedTime.split(' ');
    const timeString: string = timeParts[0];
    let [hours, minutes] = timeString.split(':').map(Number);
    if (timeParts[1] === 'PM' && hours !== 12) {
      hours += 12;
    } else if (timeParts[1] === 'AM' && hours === 12) {
      hours = 0;
    }
    const estimatedDateTime: Date = new Date(dateTimestamp);
    estimatedDateTime.setHours(hours, minutes);
    this.data.estimatedTime = estimatedDateTime;
    if (!this.data.id) {
      // new data
      this.httpService.createAnnouncement(this.data).subscribe((res) => {
        this.closeDialog();
      })
    } else {
      // update existing data
      this.httpService.updateAnnouncement(this.data.id, this.data).subscribe((res) => {
        this.closeDialog();
      })
    }
  }
}
