export interface AnnouncementModel {
  id?: string,
  name: string,
  type: string,
  averageSpeed: number,
  destinationStation: string,
  currentStation: string,
  estimatedTime: Date
}
