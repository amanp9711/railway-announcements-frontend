import { Component, OnInit } from '@angular/core';
import { HttpService } from '../../services/http.service';
import { AnnouncementModel } from '../../models/announcement.model';
import { MatTableDataSource } from '@angular/material/table';
import { RailwayTypes } from '../../models/constants';
import * as moment from 'moment';
import { io, Socket } from 'socket.io-client';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  dataSource: any = {}
  displayedColumns: string[] = ['name', 'type', 'averageSpeed', 'destinationStation', 'currentStation', 'estimatedTime'];
  private socket: Socket | undefined; // Create a socket instance

  constructor(private httpService: HttpService) {
    RailwayTypes.forEach((type) => {
      this.dataSource[type.replace(' ', '_')] = new MatTableDataSource<AnnouncementModel>([]);
    })
  }

  ngOnInit(): void {
    this.socket = io('http://localhost:3000');
    this.socket.on('updateData', (updatedData: any) => {
      if (updatedData.type) {
        this.fetchData(updatedData.type);
      } else {
        this.fetchData();
      }
    });
    this.fetchData();
    setInterval(() => {
      this.socket?.emit('checkUpdate', {});
    }, 60 * 1000)
  }

  fetchData(type?: string): void {
    if (type) {
      this.httpService.getAnnouncements(type).subscribe((res: any) => {
        this.dataSource[type.replace(' ', '_')] = res;
      })
    } else {
      RailwayTypes.forEach((type) => {
        this.httpService.getAnnouncements(type).subscribe((res: any) => {
          this.dataSource[type.replace(' ', '_')] = res;
        })
      })
    }
  }
  getTodaysDate(): string {
    return moment(new Date()).format('DD-MM-YYYY');
  }
}
