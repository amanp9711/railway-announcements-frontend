export const RailwayTypes :string[] = ['Goods','Express','Passenger','Super Fast'];
