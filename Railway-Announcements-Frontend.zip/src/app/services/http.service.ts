import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AnnouncementModel } from '../models/announcement.model';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  private backendURL = 'http://localhost:3000/announcements'
  constructor(public httpClient: HttpClient) { }

  public createAnnouncement(data: AnnouncementModel) {
    return this.httpClient.post(this.backendURL, data);
  }

  public updateAnnouncement(id: string, data: AnnouncementModel) {
    return this.httpClient.put(`${this.backendURL}/${id}`, data);
  }

  public deleteAnnouncement(id: string) {
    return this.httpClient.delete(`${this.backendURL}/${id}`);
  }

  public getAnnouncements(type?:string) {
    let params: HttpParams = new HttpParams();
    if(type){
      params = params.set('type',type);
    }
    return this.httpClient.get(this.backendURL,{params});
  }
}
